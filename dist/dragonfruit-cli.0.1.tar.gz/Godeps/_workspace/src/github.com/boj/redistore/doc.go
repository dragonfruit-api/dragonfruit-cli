/*
Package redistore is a session store backend for gorilla/sessions
*/
package redistore
