// +build !go1.1

package martini

func MartiniDoesNotSupportGo1Point0() {
	"Martini requires Go 1.1 or greater."
}
