dragonfruit
===========

Tool for creating REST APIs from arbitrary sample data.
